# python-hash
A very bad hashing library built in Python
